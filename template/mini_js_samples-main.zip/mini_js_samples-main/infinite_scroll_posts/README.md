# infinite_scroll_posts

## HTML, CSS, JS, Fetch, API, CSS loader

## https://jsonplaceholder.typicode.com
