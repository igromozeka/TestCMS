# quote_generator

## HTML CSS JS

### background - heropatterns.com

### font -Montserrat

### API - https://type.fit/api/quotes
