# js_timer

## start button
## pause button
## change timer value
## animation

### Таймер с круговой анимацией с использованием SVG

