# dom_array_methods

## forEach, map, filter, sort, reduce

## API: https://randomuser.me/
