# exchange_rate_calculator

## HTML, CSS, JS, fetch, JSON

### https://www.exchangerate-api.com/
