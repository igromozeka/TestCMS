# movie_fight

## HTML CSS JS API bulma axios

### Поиск данных по API и сравнение двух вариантов поиска
